//
//  HostingController.swift
//  NBA WATCH WatchKit Extension
//
//  Created by zappycode on 6/22/19.
//  Copyright © 2019 Nick Walter. All rights reserved.
//

import WatchKit
import Foundation
import SwiftUI

class HostingController : WKHostingController<ContentView> {
    override var body: ContentView {
        return ContentView()
    }
}
