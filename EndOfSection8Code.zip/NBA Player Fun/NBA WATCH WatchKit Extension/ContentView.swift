//
//  ContentView.swift
//  NBA WATCH WatchKit Extension
//
//  Created by zappycode on 6/22/19.
//  Copyright © 2019 Nick Walter. All rights reserved.
//

import SwiftUI

struct ContentView : View {
    var body: some View {
        Text("Hello World")
    }
}

#if DEBUG
struct ContentView_Previews : PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#endif
